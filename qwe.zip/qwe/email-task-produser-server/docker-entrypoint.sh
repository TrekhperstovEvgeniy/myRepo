#!/bin/sh

cd /email-service/bin/

exec 'java' '-Xmx512m' '-jar' './email-task-producer-0.0.1-SNAPSHOT.jar'